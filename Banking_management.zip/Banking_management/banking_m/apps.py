from django.apps import AppConfig


class BankingMConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'banking_m'
