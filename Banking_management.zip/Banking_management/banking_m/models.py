from django.db import models

# Create your models here.

Choices=(("Current", "Current"),
                    ("Savings", "Savings"),)


class Account(models.Model):
    
    Customer_ID = models.AutoField(primary_key=True)
    Name= models.CharField(max_length=20)
    Phone = models.CharField(max_length=10, null=True)
    Email = models.CharField(max_length=40)
    Account_no = models.CharField(max_length=14, null=True)
    Balance= models.IntegerField()
    Type_of_Acc= models.CharField(
                                    max_length = 10,
                                    choices = Choices,
                                    default = 'Savings'
                                    )
    IFSC_Code= models.CharField(max_length=10, null=True)
    Bank_name = models.CharField(max_length=10, null=True)
    Customer_Address= models.CharField(max_length=30, null=True)
    DOB= models.DateField()
    Adhaar_no= models.CharField(max_length=12, null=True)
    PAN = models.CharField(max_length=12, null=True)
    