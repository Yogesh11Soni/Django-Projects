from django.shortcuts import render
from django.views.generic.list import ListView
from .models import Account

# Create your views here.


class AccView(ListView):
    model = Account

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context 
    
    
    
# def search_Acc(request):
#     print(type(request.POST))
#     data = dict(request.POST)
#     print(data.keys())
#     context ={}

#     if(len(data.keys()) > 0):
        
#         entry = Account.objects.get( 
#                                         Account_no=data['number'][0],
#                                         Customer_ID=data['c_id'][0],
#                                     )   
#         context = {
#                     "c_id": entry.Customer_ID,
#                     "name": entry.Name,
#                     "phone": entry.Phone,
#                     "mail": entry.Email,
#                     "acc": entry.Account_no, 
#                     "bal": entry.Balance, 
#                     "t_acc": entry.Type_of_Acc, 
#                     "ifsc": entry.IFSC_Code, 
#                     "b_name": entry.Bank_name, 
#                     "c_add": entry.Customer_Address, 
#                     "dob": entry.DOB, 
#                     "adhaar": entry.Adhaar_no, 
#                     "pan": entry.PAN, 
                    
#                 }
#     return render(request,'index.html', context)

# def search_Acc(request):
#     if request.method =="POST":
#         #print(request.POST)
#         search_value = request.POST['number']
#         search_option = request.POST['c_id']
#         #print(request.POST)
#         if search_option =='number' and search_option == "c_id":
#             contact_data=list(Account.objects.filter(Account_no=search_value, Customer_ID=search_value))
#             # contact_data=list(Account.objects.filter(Customer_ID=search_value))
#             return render(request,'index.html',{'contact_data':contact_data})
#         # # elif search_option =='phone_number':
    
#         #    contact_data=list(Contact.objects.filter(phone_number=search_value))
#         #     #print(contact_data)
#         #     return render(request,'search.html',{'contact_data':contact_data})
#         # elif search_option =='city':
#         #     contact_data=list(Contact.objects.filter(city=search_value))
#         #     return render(request,'search.html',{'contact_data':contact_data})
#         # elif search_option =='email':
#         #     contact_data=list(Contact.objects.filter(email=search_value))

def search_Acc(request):
    """
    To show customer's details by asking for customer_id and account_number
    """
    context = {}

    data = dict(request.POST)
    print(data)
    
    if(request.POST):
        try:
            customer_details = Account.objects.get(
                                                Customer_ID=data['c_id'][0],
                                                Account_no = data['number'][0]
                                                    )
            # print(customer_details)
            context['customer_details'] = customer_details
            
        except(KeyError, Account.DoesNotExist): # if the provided key does not exist
            context['error_message'] = "This account is not registered in the database"
    return render(request, 'C:/Users/Yogi/Banking_management/banking_m/templates/index.html',context)



def delete(request):
    data= dict(request.POST)
    print(data)
    msg=''
    if(len(data.keys()) >= 1):
        acc_row = Account.objects.get(Customer_ID=data['c_id'][0])
        acc_row.delete()
    return render(request, 'C:/Users/Yogi/Banking_management/banking_m/templates/delete.html', {'msg':msg})


def banking(request):
    return render(request,"C:/Users/Yogi/Banking_management/banking_m/templates/banking.html",{})

def add(request):
    data= dict(request.POST)
    print(data)
    msg=''
    if(len(data.keys()) > 1):
        acc_row = Account(
        Name=data['name'][0],
        Phone=data['phone'][0],
        Email=data['mail'][0],
        Account_no=data['number'][0],
        Balance=data['balance'][0],
        Type_of_Acc=data['acc_type'][0],
        IFSC_Code=data['ifsc'][0],
        Bank_name=data['b_name'][0],
        Customer_Address=data['add'][0],
        Adhaar_no=data['adhaar'][0],
        PAN=data['pan'][0],
        DOB=data['dob'][0])
        
        acc_row.save()
    return render(request,"C:/Users/Yogi/Banking_management/banking_m/templates/add.html",{'msg':msg})

def transaction(request):
    def transaction(request):
        """
    
    """
    context = dict()
    message_list = list()

    if(request.POST):
        data = dict(request.POST)
        flag = True

        for key in data:
            if(data[key][0] == ''): # checking if any field is empty
                flag=False
                break
        try:
            sender = Account.objects.get(Customer_ID=data['c_id1'][0]) # checking if sender exists
        except:
            message_list.append("Sender's Account number not found!")
            flag=False

        try:
            beneficiary = Account.objects.get(Customer_ID = data['c_id2'][0]) # checking if beneficiary exist 
        except:
            message_list.append("Beneficiary's Account number not found!")
            flag = False
        
        if flag :
            
            if(sender.Balance - float(data['amount'][0]) < 0): # if sender does not have enough balance
                message_list.append("Not enough balance in sender's account to complete the transaction")
            
            else:
                transfer_money = float(data['amount'][0])
                sender.Balance -= transfer_money 
                beneficiary.Balance += transfer_money
                try:
                    sender.save()
                    beneficiary.save()
                    message_list.append("Transaction complete successfully")
                except:
                    message_list.append("ERROR")
        context['messages'] = message_list

    
    
    return render(request,"C:/Users/Yogi/Banking_management/banking_m/templates/transaction.html",context)

def update(request):
    data= dict(request.POST)
    print(data)
    msg=''
    if(len(data.keys()) >= 1):
        acc_row = Account.objects.get(Customer_ID=data['c_id'][0])
        acc_row.Name=data['name'][0]
        acc_row.Phone=data['phone'][0]
        acc_row.Email=data['mail'][0]
        # acc_row.Account_no=data['number'][0]
        acc_row.Balance=data['balance'][0]
        acc_row.Type_of_Acc=data['acc_type'][0]
        acc_row.IFSC_Code=data['ifsc'][0]
        # acc_row.Bank_name=data['b_name'][0]
        acc_row.Customer_Address=data['add'][0]
        # acc_row.Adhaar_no=data['adhaar'][0]
        # acc_row.PAN=data['pan'][0]
        acc_row.DOB=data['dob'][0]
        
        acc_row.save()
    
    return render(request,"C:/Users/Yogi/Banking_management/banking_m/templates/update.html",{})