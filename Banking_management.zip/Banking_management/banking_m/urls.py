from unicodedata import name
from django.contrib import admin
from django.urls import path,include
from banking_m.models import Account
from . import views
import banking_m
from .views import AccView, banking, delete, search_Acc



urlpatterns = [
    path('home/',views.search_Acc, name="home" ),
    path('accounts/', AccView.as_view(), name='acc-table'),
    path('delete/', views.delete, name="delete"  ),
    path('banking/', views.banking, name= 'banking'),
    path('transaction/', views.transaction, name= 'transaction'),
    path('update/', views.update, name= 'update'),
    path('add/', views.add, name= 'add'),
    
]